#include <iostream>
#include <stdlib.h>
#include <string>
#define assertdomjudge(x) if(!(x)){std::cout<<"ERROR"<<std::endl;exit(0);}

